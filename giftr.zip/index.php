<?php /*
 Theme Name:   Twenty Thirteen Child
 Theme URI:    http://example.com/twenty-thirteen-child/
 Description:  EECS 330 Giftr Theme
 Author:       Anna, Yao, Kam, and Morgan
 Author URI:   http://example.com
 Template:     twentythirteen
 Version:      1.0.0
 Text Domain:  twenty-thirteen-child

*/


    include('index.html');



?>

<style type="text/css">
@import url('../wp-content/themes/twentythirteen-child/resultpage_style.css')
</style>