<?php 
/** Header Template **/
include('header.html');
?>


<!--<link href='http://fonts.googleapis.com/css?family=PT+Sans' rel='stylesheet' type='text/css'>

<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>

<div class="row-fluid">
    <div class="row-fluid">
    	<div class="span2"><a href ="index.html">
			<img id="logo" src="Image/Logo.png" alt="giftrlogo"/>
		</div>
		<div class="span4 offset5 menu_bar">
			<ul >
		    	<li><a class = "option" href="survey1.php">Get Inspired!</a></li>
				<li><a class = "option" href="browsepage.php">Browse</a></li>
		       	<li><a class = "option" href="sharestory.php">Post a Success</a></li>
			</ul>
		</div>
	</div>

	<div class="span12">
		<img id="banner" src="Image/Ribbon.png" alt="ribbon" />
	</div>
</div>



</body>


</html>-->