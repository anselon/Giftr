


<html>
<head>
<meta charset="utf-8">
	
<head>
<title>Giftr</title>
<link href='http://fonts.googleapis.com/css?family=PT+Sans' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="sharestorystyle.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<?php 
include('header.php');
?>


<div class="spacer">
</div>


<div id ="page" class="image1"> 
	<h1 class="heading" style="font-family:'PT Sans',sans-serif;"> Browse what's popular! </h1>

 <img src="Image/Browsepage-01.png" width="900" height="550"  class="image1" alt=""/></div>

    

</body>
</html>

